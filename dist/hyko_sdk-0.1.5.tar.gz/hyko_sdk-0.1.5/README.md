# The HYKO SDK.

An AI-based automatic-prototyping framework developed by
BIGmama. It enables the dynamic and user-specific construction of AI-based applications across various industries.
`PoppAI` is a multi-model based pipeline construction framework that centralizes the capabilities of large transformer-based language models and exploits pre-trained models across tasks and modalities in a model database.
